package com.UTP.ProyectoModelo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpIntegradoApplicationTests {

	@Test
	void contextLoads() {
	}

}
